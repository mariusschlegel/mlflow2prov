from py2neo import Subgraph


def decode_graph(graph: Subgraph):
    raise NotImplementedError
